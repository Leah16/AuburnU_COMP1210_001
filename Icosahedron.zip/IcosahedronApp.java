import java.util.Scanner;
/**
* Prints out basic infomation about the shape.
* @author Shuangchen Zhou
* @version 2018.9.19
*/
public class IcosahedronApp  {
   /**
   * Asking for a icosahedron and finding some basic math infomation.
   * @param args not used.
   */
   public static void main(String[] args) {
      //Scanner
      Scanner scan = new Scanner(System.in);
      //Output
      System.out.println("Enter label, color, and edge length for an "
         + "icosahedron.");
      //Input
      System.out.print("\tlabel: ");
      String label = scan.nextLine();
      
      System.out.print("\tcolor: ");
      String color = scan.nextLine();
      
      System.out.print("\tedge: ");
      double edge = scan.nextDouble();
      //Checking
      if (edge > 0) {
         Icosahedron shape;
         shape = new Icosahedron(label, color, edge);
         System.out.println("\n" + shape.toString());
      } 
      else {
         System.out.println("Error: edge must be greater than 0.");
      
      }
   }
}      
      